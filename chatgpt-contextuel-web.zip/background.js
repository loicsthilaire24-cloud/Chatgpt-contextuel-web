chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "open-chatgpt-web",
    title: "Ouvrir ChatGPT",
    contexts: ["all"]
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "open-chatgpt-web") {
    chrome.windows.create({
      url: "https://chat.openai.com",
      type: "popup",
      width: 400,
      height: 600
    });
  }
});